<?php

// require_once __DIR__ . '/../app/middleware/AuthMiddleware.php';

use App\Router;
use App\Middleware\AuthMiddleware;
use Controllers\HomeController;
use Controllers\userController;

Router::get('/', function () {
    (new HomeController)->index();
});
Router::get('/home', function () {
    (new HomeController)->home();
});

Router::post('/register', function () {
    (new userController)->createUser();
});

Router::post('/login', function () {
    (new userController)->login();
});

Router::group(['middleware' => [AuthMiddleware::class]], function(){
    Router::post('/user', function() {
        (new userController)->userData();
    });

    Router::post('/logout', function() {
        (new userController)->logout();
    });
});

// Router::post('/user', function () {
//         (new userController)->userData();
// }, AuthMiddleware::class);

// Router::post('/logout', function() {
//     (new userController)->logout();
// },AuthMiddleware::class);

Router::dispatch();

<?php

namespace App;

use App\Database;

class BaseModel {
    protected $db;
    protected $collection;

    public function __construct() {
        $this->db = Database::getInstance()->getDB();

        // Set collection dynamically based on the child class name
        if (!$this->collection) {
            $className = strtolower((new \ReflectionClass($this))->getShortName());
            $this->collection = $this->db->selectCollection($className);
        }

        $this->collection = $this->db->selectCollection($this->collection);
    }

    public static function create($data) {
        $instance = new static(); // Use `static` for late static binding
        return $instance->collection->insertOne($data);
    }
           
    public static function find($filter = []): array{
        $instance = new static();
        $data = $instance->collection->find($filter)->toArray();
        return $data;
    }

    public static function findOne($filter) {
        $instance = new static();
        return $instance->collection->findOne($filter);
    }

    public static function All(): array {
        $instance = new static();
        $data = $instance->collection->find([])->toArray();
        return $data;
    }
}


// namespace App;

// use App\Database;
// use MongoDB\InsertOneResult;
// use MongoDB\DeleteResult;
// use MongoDB\UpdateResult;
// use Exception;
// use ReflectionClass;

// class BaseModel {
//     protected $db;
//     protected $collection;

//     public function __construct() {
//         $this->db = Database::getInstance()->getDB();
        
//         if (!is_object($this->db)) {
//             die("Error: DB connection is not a valid object.");
//         }
        
//         if (!$this->collection) {
//             $className = strtolower((new \ReflectionClass($this))->getShortName());
//             $this->collection = $this->db->selectCollection($className);
//         }
        
//         if (!is_object($this->collection)) {
//             die("Error: Collection is not a valid MongoDB collection object. Value: " . print_r($this->collection, true));
//         }
//     }
    

//     /**
//      * Insert a new document into the collection.
//      *
//      * @param array $data
//      * @return InsertOneResult
//      */
//     public static function create(array $data): InsertOneResult {
//         $instance = new static(); // Late static binding
//         return $instance->collection->insertOne($data);
//     }

//     /**
//      * Find documents matching a filter.
//      *
//      * @param array $filter
//      * @return array
//      */
//     public static function find(array $filter = []): array {
//         $instance = new static();
//         $data = $instance->collection->find($filter)->toAarray();
//         return $data;
//     }

//     /**
//      * Find a single document matching a filter.
//      *
//      * @param array $filter
//      * @return mixed
//      */
//     public static function findOne(array $filter) {
//         $instance = new static();
//         return $instance->collection->findOne($filter);
//     }

//     /**
//      * Get all documents from the collection.
//      *
//      * @return array
//      */
//     public static function all(): array {
//         $instance = new static();
//         $data = $instance->collection->find([])->toArray();
//         return $data;
//     }

//     /**
//      * Update document(s) in the collection.
//      *
//      * @param array $filter
//      * @param array $data
//      * @return UpdateResult
//      */
//     public static function update(array $filter, array $data): UpdateResult {
//         $instance = new static();
//         return $instance->collection->updateOne($filter, ['$set' => $data]);
//     }

//     /**
//      * Delete document(s) from the collection.
//      *
//      * @param array $filter
//      * @return DeleteResult
//      */
//     public static function delete(array $filter): DeleteResult {
//         $instance = new static();
//         return $instance->collection->deleteOne($filter);
//     }
// }

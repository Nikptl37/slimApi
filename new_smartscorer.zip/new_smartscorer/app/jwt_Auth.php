<?php

namespace App;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Auth {

    private static $secret_key = "66571785bbab498f631276a992332d6248db8175a74d048d167cdb6e8a4bb608";
    // private static $algorithm = "HS256";


    public static function generateToken($user){
        $playload = [
            'iat' => time(),
            'exp' => time() + 3600,
            'user' => $user
        ];

        return JWT::encode($playload, self::$secret_key,'HS256');
    }

    public static function verifyOtp() {
        $headers = getallheaders();
        $token = str_replace('Bearer ', '', $headers['Authorization']);
        try {
            $decoded = JWT::decode($token, new Key(self::$secret_key, 'HS256'));
            return (array) $decoded->user;
        } catch (\Exception $e) {
            return null; // Return the exception message for debugging
        }
    }
    

    public static function check(){
       return self::verifyOtp() ?? null;
    }

    public static function user(){
        return self::verifyOtp();
    }

}
<?php

namespace App;

session_start();

class Auth
{

    public static function startSession()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Set the session cookie manually
        $cookie_name = session_name();
        $cookie_value = session_id();
        $lifetime = 60; // 6 months
        $expires = time() + $lifetime;
        $domain = ini_get('session.cookie_domain') ?: $_SERVER['HTTP_HOST'];
        $path = ini_get('session.cookie_path') ?: '/';
        $secure = true;
        $httponly = true;
        $samesite = 'None';

        $set_cookie_header = "Set-Cookie: $cookie_name=$cookie_value; expires=" . gmdate('D, d-M-Y H:i:s T', $expires) . "; path=$path; domain=$domain; secure; HttpOnly; SameSite=$samesite; Partitioned";

        header($set_cookie_header);
    }

    public static function generateToken($user)
    {
        self::startSession();
        $_SESSION['user'] = $user;
        
        return session_id();
        // setcookie("session_token", session_id(), time() + 120, "/");    
    }


    public static function check()
    {
        return isset($_SESSION['user']);
    }

    public static function user()
    {
        self::startSession();
        return $_SESSION['user'] ?? null;
    }

    public static function logout()
    {
        self::startSession();
        $CookieInfo = session_get_cookie_params();
        $arr_cookie_options = array(
            'expires' => 1,
            'path' => '/',
            'httponly' => true,
            'samesite' => 'None'
        );
        setcookie(session_name(), 'logout session', $arr_cookie_options);
        session_destroy();
    }
}

<?php

namespace App;

class Router
{
    private static $routes = [];
    private static $middlewareGroup = [];

    public static function get($route, $callback, $middleware = [])
    {
        self::addRoute('GET', $route, $callback, $middleware);
    }

    public static function post($route, $callback, $middleware = [])
    {
        self::addRoute('POST', $route, $callback, $middleware);
    }

    private static function addRoute($method, $route, $callback, $middleware = []){
        $middleware = array_merge(self::$middlewareGroup, (array) $middleware);

        self::$routes[$method][$route] = [
            'callback' => $callback,
            'middleware' => $middleware
        ];
    }

    public static function group($options, $callback){
        self::$middlewareGroup = $options['middleware'] ?? [];

        $callback();

        self::$middlewareGroup = [];
    }  
    
    public static function dispatch()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        require_once __DIR__ . '/cros.php';

        // Handle preflight (OPTIONS request)
        if ($method === 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        // Check if route exists
        if (isset(self::$routes[$method][$uri])) {
            $routeData = self::$routes[$method][$uri];
            $middlewareStack = $routeData['middleware'] ?? [];

            // Process middleware chain
            $callback = $routeData['callback'];
            foreach (array_reverse($middlewareStack) as $middlewareClass) {
                $callback = function () use ($middlewareClass, $callback) {
                    $middlewareClass::handle($callback);
                };
            }

            // Execute final callback
            call_user_func($callback);
        } else {
            http_response_code(404);
            echo json_encode(['error' => "Route Not Found"]);
        }
    }

    // public static function dispatch()
    // {
    //     $method = $_SERVER['REQUEST_METHOD'];
    //     $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    //     require_once __DIR__ . '/cros.php';

    //     // Handle preflight (OPTIONS request)
    //     if ($method === 'OPTIONS') {
    //         http_response_code(200);
    //         exit();
    //     }

    //     // Check if route exists
    //     if (isset(self::$routes[$method][$uri])) {
    //         $routeData = self::$routes[$method][$uri];

    //         if ($routeData['middleware']) {
    //             $middlewareClass = $routeData['middleware'];
    //             $middlewareClass::handle($routeData['callback']);
    //         } else {
    //             call_user_func($routeData['callback']);
    //         }
    //     } else {
    //         http_response_code(404);
    //         echo json_encode(['error' => "Route Not Found"]);
    //     }
    // }
}

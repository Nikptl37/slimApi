<?php

require_once '../vendor/autoload.php';



require_once '../routes/api.php';

// Handle pre-flight requests (OPTIONS method) for CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0); // Exit early for OPTIONS requests
}
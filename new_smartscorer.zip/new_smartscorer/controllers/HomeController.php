<?php

namespace Controllers;
class HomeController{
     
    public function index(){
        echo json_encode(['status_code' => 200, 'message' =>  'hello']);
        // echo json_encode(['status_code' => 200, 'message' =>  bin2hex(random_bytes(32))]);
    }


    public function home(){
        echo json_encode(['status_code' => 200, 'message' => 'this is home api']);
    }
}

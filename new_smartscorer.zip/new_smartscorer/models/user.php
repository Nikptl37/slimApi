<?php

namespace Models;

use App\BaseModel;

class User extends BaseModel {
    protected $collection = 'Users';

    public function __construct()
    {
        parent::__construct();
    }
}
